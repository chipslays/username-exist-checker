<?php
namespace app\modules;

use std, gui, framework, app;


class MainModule extends AbstractModule
{

    /**
     * @event timer.action 
     */
    function doTimerAction(ScriptEvent $e = null)
    {    
        global $base_url, $not_found, $ids, $count_ids;
        
        $id = array_shift($ids);
        $key = $count_ids - count($ids);
        
        
    }

}
