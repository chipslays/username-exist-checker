<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{
    
    public static function sampling($chars, $size, $combinations = []) {
        if (empty($combinations)) {
            $combinations = $chars;
        }
    
        if ($size == 1) {
            return $combinations;
        }
    
        $new_combinations = array();
    
        foreach ($combinations as $combination) {
            foreach ($chars as $char) {
                $new_combinations[] = $combination . $char;
            }
        }
    
        return self::sampling($chars, $size - 1, $new_combinations);
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        global $base_url, $not_found, $ids, $count_ids, $res;
        
        $chars = array_filter(str_split(trim($this->preset->selected)));   
        $base_url = trim($this->url->text);
        $not_found = trim($this->not_found->text);
        $len = trim($this->len->text);
        $ids = array_unique(self::sampling($chars, $len));
        $chunks = trim($this->chunks->text);
        
        $count_ids = count($ids);

        $res['index'] = 0;
        $res['good'] = [];
        $res['bad'] = [];
        
        $this->textArea->clear();
        
        foreach (array_chunk($ids, $chunks) as $ids) {
             $thread = new Thread(function () use ($ids, $count_ids, $not_found, $base_url) {
                global $res;
                foreach($ids as $key => $id) {
                    $url = str_ireplace('{{id}}', $id, $base_url);
                     
                    //$html = file_get_contents($url);
                    $ch = curl_init($url); 
                    curl_setopt_array($ch, [
                       CURLOPT_RETURNTRANSFER => true
                    ]);   
                    
                    $html = curl_exec($ch);
                    curl_close($ch); 
                    
                    if (stripos($html, $not_found) !== false) {
                        $res['good'][] = $id;
                        
                        uiLater(function() use ($id) {
                            $this->textArea->text = $id . "\n" . $this->textArea->text;
                        });
                    } else {
                        $res['bad'][] = $id;
                    }    
                        
                    $res['index'] = $res['index'] + 1;    
                    $count_bad = count($res['bad']);
                    $count_good = count($res['good']);
                    $index = $res['index'];
                    
                    uiLater(function() use ($index, $id, $count_ids, $count_bad, $count_good) {
                        $this->log->text = "Комбинаций: {$index}/{$count_ids}\nТекущий: {$id}\nЗанятые: {$count_bad}\nСвободные: {$count_good}\n";
                    });
    
                }
            });
        
            $thread->start(); 
        }
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        UXClipboard::setText($this->textArea->text);
        $this->toast("Скопировано в буфер");
    }

    /**
     * @event link.action 
     */
    function doLinkAction(UXEvent $e = null)
    {    
        UXClipboard::setText('https://github.com/aethletic/username-exist-checker');
        $this->toast("Скопировано в буфер");
        
    }

    /**
     * @event linkAlt.action 
     */
    function doLinkAltAction(UXEvent $e = null)
    {    
        $res =  explode("\n", $this->textArea->text);
        sort($res);
        $this->textArea->text = trim(implode("\n", $res));
        
        $this->toast("Список отсортирован");
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        $this->preset->selectedIndex = 0;
    }

}
